import xbmcaddon
import xbmcgui
import xbmcplugin
import sys

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'videos')

playlist_url = 'https://raw.githubusercontent.com/RockMachineRadio/Rock-Radio-TV/main/IPTV_Rock_List.m3u'

li = xbmcgui.ListItem(label='🎸 Lista RockTV')
li.setArt({'thumb': 'https://i.imgur.com/yMC3wxL.jpg', 'icon': 'https://i.imgur.com/yMC3wxL.jpg', 'fanart': 'https://i.imgur.com/DodIDF7.jpg'})
li.setInfo('video', {'title': 'Lista IPTV RockTV'})
xbmcplugin.addDirectoryItem(handle=addon_handle, url=playlist_url, listitem=li)
xbmcplugin.endOfDirectory(addon_handle)
